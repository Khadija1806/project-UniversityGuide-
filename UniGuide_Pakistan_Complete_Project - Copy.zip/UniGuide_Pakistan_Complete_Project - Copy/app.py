from flask import Flask, render_template, request, jsonify, abort
from data_store import UNIVERSITIES, CITIES, PROGRAMMES
from algorithms.graph import build_graph
from algorithms.traversal import bfs, dfs
from eligibility import check_eligibility

app = Flask(__name__)
app.secret_key = "change-this-local-development-key"

def by_id(uid):
    return next((u for u in UNIVERSITIES if u["id"] == uid), None)

def city_results(city):
    graph = build_graph(UNIVERSITIES)
    visited = bfs(graph, f"city:{city}")
    ids = [n.split(":", 1)[1] for n in visited if n.startswith("university:")]
    lookup = {u["id"]: u for u in UNIVERSITIES}
    return [lookup[i] for i in ids if i in lookup]

@app.route("/")
def home():
    return render_template("home.html", universities=UNIVERSITIES, cities=CITIES, programmes=PROGRAMMES)

@app.route("/cities")
def cities():
    return render_template("cities.html", cities=CITIES)

@app.route("/student")
def student():
    return render_template("student.html", cities=CITIES, programmes=PROGRAMMES)

@app.route("/universities")
def universities():
    q = request.args.get("q", "").strip().casefold()
    city = request.args.get("city", "")
    kind = request.args.get("type", "")
    programme = request.args.get("programme", "").strip().casefold()
    if city:
        results = city_results(city)
    else:
        graph = build_graph(UNIVERSITIES)
        visited = bfs(graph, "country:Pakistan")
        ids = [n.split(":", 1)[1] for n in visited if n.startswith("university:")]
        lookup = {u["id"]: u for u in UNIVERSITIES}
        results = [lookup[i] for i in ids if i in lookup]
    if q:
        results = [u for u in results if q in u["name"].casefold() or q in u["city"].casefold() or any(q in p.casefold() for p in u["programmes"])]
    if kind:
        results = [u for u in results if u["type"] == kind]
    if programme:
        results = [u for u in results if any(programme in p.casefold() for p in u["programmes"])]
    return render_template("universities.html", universities=results, cities=CITIES, programmes=PROGRAMMES, query=q, selected_city=city, selected_type=kind, selected_programme=programme)

@app.route("/university/<uid>")
def university_detail(uid):
    u = by_id(uid)
    if not u: abort(404)
    traversal = dfs(build_graph(UNIVERSITIES), f"university:{uid}")
    return render_template("university_detail.html", university=u, traversal=traversal)

@app.route("/eligibility")
def eligibility():
    student_data = {
        "name": request.args.get("name", ""),
        "percentage": request.args.get("percentage", ""),
        "city": request.args.get("city", ""),
        "programme": request.args.get("programme", "")
    }

    results = []

    if student_data["percentage"] or student_data["city"] or student_data["programme"]:
        results = check_eligibility(student_data, UNIVERSITIES)

    return render_template(
        "eligibility.html",
        cities=CITIES,
        programmes=PROGRAMMES,
        student=student_data,
        results=results
    )

@app.route("/api/eligibility", methods=["POST"])
def eligibility_api():
    return jsonify(check_eligibility(request.get_json(silent=True) or {}, UNIVERSITIES))

@app.route("/documents")
def documents():
    return render_template("documents.html", universities=UNIVERSITIES)

@app.route("/api/documents/<uid>")
def documents_api(uid):
    u = by_id(uid)
    return (jsonify(u["documents"]) if u else (jsonify({"error":"Not found"}),404))

@app.errorhandler(404)
def missing(e):
    return render_template("not_found.html"), 404

if __name__ == "__main__":
    app.run(debug=True)
