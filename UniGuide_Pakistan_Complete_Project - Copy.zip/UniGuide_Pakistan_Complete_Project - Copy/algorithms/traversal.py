from collections import deque
def bfs(graph,start):
    if start not in graph:return []
    q=deque([start]); seen={start}; out=[]
    while q:
        n=q.popleft(); out.append(n)
        for x in graph.get(n,[]):
            if x not in seen:seen.add(x);q.append(x)
    return out
def dfs(graph,start):
    if start not in graph:return []
    stack=[start];seen=set();out=[]
    while stack:
        n=stack.pop()
        if n in seen:continue
        seen.add(n);out.append(n);stack.extend(reversed(graph.get(n,[])))
    return out
