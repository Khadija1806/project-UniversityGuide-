from collections import defaultdict
def build_graph(universities):
    g=defaultdict(list); g["country:Pakistan"]=[]
    for u in universities:
        c=f"city:{u['city']}"; n=f"university:{u['id']}"
        if c not in g["country:Pakistan"]: g["country:Pakistan"].append(c)
        g[c].append(n)
        for p in u["programmes"]:
            pn=f"programme:{u['id']}:{p}"; g[n].append(pn); g[pn].append(f"documents:{u['id']}")
        g[f"documents:{u['id']}"]=[f"document:{u['id']}:{d['id']}" for d in u["documents"]]
    return g
