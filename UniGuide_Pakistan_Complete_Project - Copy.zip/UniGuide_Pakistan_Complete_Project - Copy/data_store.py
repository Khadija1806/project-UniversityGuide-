CITIES = sorted(["Abbottabad","Bahawalpur","Faisalabad","Gujranwala","Hyderabad","Islamabad","Karachi","Lahore","Multan","Peshawar","Quetta","Rawalpindi","Sialkot","Sukkur"])
PROGRAMMES = ["Computer Science","Software Engineering","Artificial Intelligence","Data Science","Cyber Security","Information Technology","Computer Engineering","Electrical Engineering","Mechanical Engineering","Civil Engineering","Biomedical Engineering","MBBS","BDS","Nursing","Pharmacy","Biotechnology","Microbiology","Biochemistry","BBA","Accounting and Finance","Economics","Psychology","Media Studies","Law","English","Education","Architecture","Mathematics","Physics"]
DOCS = [
 {"id":"cnic","name":"CNIC / B-Form","category":"Mandatory","description":"Applicant identity document."},
 {"id":"photo","name":"Recent photographs","category":"Mandatory","description":"As specified by the university."},
 {"id":"matric","name":"Matric certificate / marksheet","category":"Mandatory","description":"Matriculation academic record."},
 {"id":"inter","name":"Intermediate certificate / marksheet","category":"Mandatory","description":"Intermediate or equivalent academic record."},
 {"id":"domicile","name":"Domicile certificate","category":"Conditional","description":"Required by some institutions or admission categories."},
 {"id":"test","name":"Entry test result","category":"Conditional","description":"Required where the programme or university demands it."}
]
def make(uid,name,city,kind,programmes,website):
 return {"id":uid,"name":name,"city":city,"type":kind,"campus":"Main Campus","programmes":programmes,"website":website,"documents":[dict(x) for x in DOCS]}
UNIVERSITIES = [
 make("u01","University of Karachi","Karachi","Public",["Computer Science","Software Engineering","Artificial Intelligence","Data Science","Biotechnology","Microbiology","Pharmacy","BBA","Economics","Psychology","Law","English","Mathematics","Physics"],"https://uok.edu.pk/"),
 make("u02","NED University of Engineering and Technology","Karachi","Public",["Computer Science","Software Engineering","Artificial Intelligence","Cyber Security","Computer Engineering","Electrical Engineering","Mechanical Engineering","Civil Engineering","Biomedical Engineering"],"https://www.neduet.edu.pk/"),
 make("u03","National University of Sciences and Technology (NUST)","Islamabad","Public",["Computer Science","Software Engineering","Artificial Intelligence","Data Science","Cyber Security","Electrical Engineering","Mechanical Engineering","Civil Engineering","Biomedical Engineering","BBA","Economics","Psychology"],"https://nust.edu.pk/"),
 make("u04","Quaid-i-Azam University","Islamabad","Public",["Computer Science","Information Technology","Biotechnology","Biochemistry","Economics","Psychology","Law","English","Mathematics","Physics"],"https://qau.edu.pk/"),
 make("u05","COMSATS University Islamabad","Islamabad","Public",["Computer Science","Software Engineering","Artificial Intelligence","Data Science","Cyber Security","Electrical Engineering","Computer Engineering","BBA","Accounting and Finance","Psychology","Biotechnology"],"https://www.comsats.edu.pk/"),
 make("u06","University of the Punjab","Lahore","Public",["Computer Science","Software Engineering","Information Technology","Artificial Intelligence","Electrical Engineering","Pharmacy","Biotechnology","BBA","Accounting and Finance","Economics","Psychology","Law","English","Education"],"https://pu.edu.pk/"),
 make("u07","University of Engineering and Technology Lahore","Lahore","Public",["Computer Science","Software Engineering","Electrical Engineering","Mechanical Engineering","Civil Engineering","Biomedical Engineering","Computer Engineering","Architecture"],"https://www.uet.edu.pk/"),
 make("u08","Lahore University of Management Sciences (LUMS)","Lahore","Private",["Computer Science","Electrical Engineering","BBA","Economics","Accounting and Finance","Psychology","Law"],"https://lums.edu.pk/"),
 make("u09","University of Lahore","Lahore","Private",["Computer Science","Software Engineering","Artificial Intelligence","Data Science","Cyber Security","MBBS","BDS","Pharmacy","Nursing","Biotechnology","BBA","Psychology","Law"],"https://uol.edu.pk/"),
 make("u10","Aga Khan University","Karachi","Private",["MBBS","Nursing","Education"],"https://www.aku.edu/"),
 make("u11","Dow University of Health Sciences","Karachi","Public",["MBBS","BDS","Nursing","Pharmacy","Biotechnology"],"https://www.duhs.edu.pk/"),
 make("u12","Bahria University","Islamabad","Public",["Computer Science","Software Engineering","Artificial Intelligence","Data Science","Cyber Security","Electrical Engineering","BBA","Accounting and Finance","Psychology","Media Studies"],"https://bahria.edu.pk/"),
 make("u13","Air University","Islamabad","Public",["Computer Science","Software Engineering","Artificial Intelligence","Cyber Security","Data Science","Electrical Engineering","Mechanical Engineering","BBA"],"https://www.au.edu.pk/"),
 make("u14","University of Peshawar","Peshawar","Public",["Computer Science","Pharmacy","Biotechnology","BBA","Economics","Psychology","Law","English","Education"],"https://uop.edu.pk/"),
 make("u15","Bahauddin Zakariya University","Multan","Public",["Computer Science","Information Technology","Electrical Engineering","Pharmacy","Biotechnology","BBA","Economics","Psychology","Law","English","Education"],"https://bzu.edu.pk/"),
 make("u16","University of Agriculture Faisalabad","Faisalabad","Public",["Computer Science","Biotechnology","Microbiology","Biochemistry","BBA","Economics"],"https://uaf.edu.pk/"),
 make("u17","Mehran University of Engineering and Technology","Jamshoro","Public",["Computer Science","Software Engineering","Artificial Intelligence","Electrical Engineering","Mechanical Engineering","Civil Engineering"],"https://www.muet.edu.pk/"),
 make("u18","Sukkur IBA University","Sukkur","Public",["Computer Science","Software Engineering","Artificial Intelligence","Electrical Engineering","BBA","Accounting and Finance","Economics"],"https://www.iba-suk.edu.pk/"),
 make("u19","Ghulam Ishaq Khan Institute (GIKI)","Topi","Private",["Computer Science","Artificial Intelligence","Data Science","Electrical Engineering","Mechanical Engineering","Computer Engineering"],"https://giki.edu.pk/"),
 make("u20","Institute of Business Administration (IBA) Karachi","Karachi","Public",["Computer Science","BBA","Accounting and Finance","Economics","Psychology","Media Studies"],"https://www.iba.edu.pk/")
]
