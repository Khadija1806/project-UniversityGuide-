def check_eligibility(payload, universities):
    city = str(payload.get("city","")).strip()
    programme = str(payload.get("programme","")).strip().casefold()
    results = []
    for u in universities:
        if city and u["city"] != city: continue
        for p in u["programmes"]:
            if programme and programme not in p.casefold(): continue
            results.append({"university":u["name"],"programme":p,"status":"Additional Requirements Needed","reason":"Check the current official prospectus for required marks, subjects, entry tests and campus-specific criteria.","website":u["website"]})
    return results
