# UniGuide Pakistan
Complete Flask starter project with shared templates, responsive styling, university search, city and programme filters, eligibility discovery, document checklist and BFS/DFS graph traversal.

## Run on Windows
1. Extract the ZIP and open the folder in VS Code.
2. Open Terminal in that folder.
3. Run: `python -m venv venv`
4. Run: `venv\Scripts\activate`
5. Run: `pip install -r requirements.txt`
6. Run: `python app.py`
7. Open: http://127.0.0.1:5000

## Important data note
This package contains 20 starter university records, not 100. Programme lists are starter examples, not exhaustive verified catalogues. Verify active campuses, programme availability, recognition and admission criteria using HEC and each university's current official prospectus before publishing. The eligibility checker intentionally returns "Additional Requirements Needed" instead of inventing admission cutoffs.
